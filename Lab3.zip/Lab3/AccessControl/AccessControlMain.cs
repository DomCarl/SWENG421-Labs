﻿using System;

namespace AccessControl
{
    class AccessControlMain
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello World!");
        }
    }
}